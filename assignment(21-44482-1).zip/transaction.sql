-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 17, 2023 at 11:40 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `transaction`
--

-- --------------------------------------------------------

--
-- Table structure for table `pending_transaction_log`
--

CREATE TABLE `pending_transaction_log` (
  `id` int(10) NOT NULL,
  `transaction_name` varchar(100) NOT NULL,
  `transaction_details` text NOT NULL,
  `transaction_price` int(7) NOT NULL,
  `created_by` int(10) NOT NULL,
  `created_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pending_transaction_log`
--

INSERT INTO `pending_transaction_log` (`id`, `transaction_name`, `transaction_details`, `transaction_price`, `created_by`, `created_time`) VALUES
(93, 'user2', 'xyz', 30, 1, '2023-08-17 14:19:03'),
(94, 'user2', 'cycle rent', 5, 1, '2023-08-17 14:55:40');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `transaction_name` varchar(100) NOT NULL,
  `transaction_details` text NOT NULL,
  `transaction_price` int(7) NOT NULL,
  `created_by` int(10) NOT NULL,
  `created_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `transaction_name`, `transaction_details`, `transaction_price`, `created_by`, `created_time`) VALUES
(88, 'user1', 'bike rent', 100, 1, '2023-08-17 09:50:27'),
(89, 'user2', 'Current Bill', 50, 1, '2023-08-17 10:38:18'),
(90, 'user1', 'Buy internet', 20, 1, '2023-08-17 11:23:41'),
(91, 'shafwan', 'abcdefg', 20, 3, '2023-08-17 11:39:00'),
(92, 'user2', 'mu sus', 30, 1, '2023-08-17 11:43:11');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL,
  `user_name` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL,
  `deposite` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_name`, `password`, `deposite`) VALUES
(1, 'shafwan', '123456', 500),
(2, 'user2', '123456', 500),
(3, 'user1', '123456', 500);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pending_transaction_log`
--
ALTER TABLE `pending_transaction_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_name` (`user_name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pending_transaction_log`
--
ALTER TABLE `pending_transaction_log`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
