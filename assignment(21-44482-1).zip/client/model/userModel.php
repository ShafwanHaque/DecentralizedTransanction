<?php
require_once("../db/db_connection.php");

function authenticate($username, $password) {
    global $conn;
    $sql = "SELECT * FROM users WHERE user_name = '$username' and password = '$password';";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);

    if ($row) {
        return $row;
    }
    return false;
}

function isUserNameExist($username)
{
    global $conn;
    $sql = "SELECT * FROM users WHERE user_name = '$username';";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);

    if ($row) {
        return true;
    }
    return false;
}

function storeUserData($username, $password)
{
    global $conn;
    $sql = "INSERT INTO users (user_name, password) VALUES ('$username', '$password');";

    if ($conn->query($sql) === TRUE) {
        return true;
    } else {
        return false;
    }
}
