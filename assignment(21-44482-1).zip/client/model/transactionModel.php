<?php
require_once("../db/db_connection.php");
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function contract($transaction_name, $transaction_details, $transaction_price)
{
    global $conn;
    $created_by_id = $_SESSION['userId'];
    $created_by_name = $_SESSION['userName'];
    date_default_timezone_set('Asia/Dhaka');
    $created_time = date("Y-m-d H:i:s");
    $sql = "INSERT INTO pending_transaction_log (transaction_name, transaction_details, transaction_price, created_by,  created_time)
        VALUES ('$transaction_name', '$transaction_details', '$transaction_price', '$created_by_id', '$created_time');";

    if ($conn->query($sql) === TRUE) {
        $lastInsertedId = $conn->insert_id;
        // sending data to validator app
        $url = 'http://localhost/validator/controller/transactionApi.php';

        $newEntry = array(
            "id" => $lastInsertedId,
            "transaction_name" => $transaction_name,
            "transaction_details" => $transaction_details,
            "transaction_price" => $transaction_price,
            "created_by_id" => $created_by_id,
            "created_by_name" => $created_by_name,
            "created_time" => $created_time,
            "vote" => 0,
        );

        $postData = http_build_query(array('data' => json_encode($newEntry)));

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);
        curl_close($ch);

        if ($response === false) {
            return false;
        } else {
            return true;
        }
    }
    return false;
}

function storeApprovedData($data) {
    $transaction = gettransaction($data['id']);
    global $conn;
    if ($transaction) {
        $transaction_id = $transaction["id"];
        $transaction_name = $transaction["transaction_name"];
        $transaction_details = $transaction["transaction_details"];
        $transaction_price = $transaction["transaction_price"];
        $created_by_id = $transaction["created_by"];
        $created_time = $transaction["created_time"];

        $sql = "INSERT INTO transactions (id, transaction_name, transaction_details, transaction_price, created_by, created_time)
        VALUES ('$transaction_id', '$transaction_name', '$transaction_details', '$transaction_price', '$created_by_id', '$created_time');";


        if ($conn->query($sql) === TRUE) {
            deletePendingtransaction($data['id']);
            return true;
        } else {
            return false;
        }
    }
}

function getAlltransactions($created_by)
{
    global $conn;
    $sql = "SELECT * FROM (
            SELECT id, transaction_name, transaction_details, transaction_price, created_by, created_time, 'Pending' AS status
            FROM pending_transaction_log
            WHERE created_by = '$created_by'
            UNION
            SELECT id, transaction_name, transaction_details, transaction_price, created_by, created_time, 'Approved' AS status
            FROM transactions
            WHERE created_by = '$created_by'
        ) AS combined_data
        ORDER BY created_time DESC;";

        $result = mysqli_query($conn, $sql);

        if (!$result) {
            echo "Query failed: " . mysqli_error($conn);
            return [];
        }

        $transactions = [];

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $transactions[] = $row;
            }
        }

        return $transactions;
}

function gettransaction($id)
{
    global $conn;
    $sql = "SELECT * FROM pending_transaction_log WHERE id = '$id'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);

    if ($row) {
        return $row;
    }
    return false;
}

function deletePendingtransaction($id)
{
    global $conn;
    $sql = "DELETE FROM pending_transaction_log WHERE id = '$id'";
    if (mysqli_query($conn, $sql)) {
        return true;
    }
    return false;
}
