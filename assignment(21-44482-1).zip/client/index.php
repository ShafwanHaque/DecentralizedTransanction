<?php
    header("Location: view/login.php");
    exit();
