<?php
require_once("../controller/loginProcess.php");
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (isset($_SESSION['userId'])) {
    header("Location: transaction_list.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['login'])) {
    $username = $_POST["username"];
    $password = $_POST["password"];

    authenticateProcess($username, $password);
}
?>
<!DOCTYPE html>
<html>

<head>
    <title>User Login</title>
    <link rel="stylesheet" type="text/css" href="../public/css/style.css">
</head>

<body>
    <h2>User Login</h2>
    <span class="error">
        <?php
        if (isset($_SESSION["login_error"])) {
            echo $_SESSION["login_error"];
            unset($_SESSION["login_error"]);
        }
        ?>
    </span>
    <span class="success">
        <?php
        if (isset($_SESSION["registration_success"])) {
            echo $_SESSION["registration_success"];
            unset($_SESSION["registration_success"]);
        }
        ?>
    </span>
    <form method="post" action="">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username"><br><br>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password"><br><br>
        <input type="submit" name="login" value="Login">
    </form>
    <a href="registration.php">Register</a>
</body>

</html>
