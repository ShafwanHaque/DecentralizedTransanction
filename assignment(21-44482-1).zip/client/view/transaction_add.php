<?php
require_once("../controller/transactionProcess.php");
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['userId'])) {
    header("Location: login.php");
    exit();
}

$oldtransactionId = '';
$oldtransactionDetails = '';
$oldtransactionPrice = '';

if (isset($_SESSION['oldtransactionId'])) {
    $oldtransactionId = $_SESSION['oldtransactionId'];
    unset($_SESSION['oldtransactionId']);
}
if (isset($_SESSION['oldtransactionDetails'])) {
    $oldtransactionDetails = $_SESSION['oldtransactionDetails'];
    unset($_SESSION['oldtransactionDetails']);
}
if (isset($_SESSION['oldtransactionPrice'])) {
    $oldtransactionPrice = $_SESSION['oldtransactionPrice'];
    unset($_SESSION['oldtransactionPrice']);
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['add_transaction'])) {
    $transaction_name = $_POST["transaction_name"];
    $transaction_details = $_POST["transaction_details"];
    $transaction_price = $_POST["transaction_price"];

    addtransactionProcess($transaction_name, $transaction_details, $transaction_price);
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Add Transaction</title>
    <link rel="stylesheet" type="text/css" href="../public/css/style.css">
</head>

<body>
    <?php include 'include/topbar.php'; ?>
    <h2>Add Transaction</h2>

    <?php
    if (isset($_SESSION['transactionInsertSuccess'])) {
        $transactionInsertSuccess = $_SESSION['transactionInsertSuccess'];
        unset($_SESSION['transactionInsertSuccess']);
    ?>
        <span class="success"><?= $transactionInsertSuccess; ?></span><br>
    <?php
    }
    ?>
    <?php
    if (isset($_SESSION['transactionInsertError'])) {
        $transactionInsertError = $_SESSION['transactionInsertError'];
        unset($_SESSION['transactionInsertError']);
    ?>
        <span class="error"><?= $transactionInsertError; ?></span><br>
    <?php
    }
    ?>
    <form action="" method="post">
        <label for="transaction_name">Transaction ID:</label>
        <input type="text" id="transaction_name" name="transaction_name" value="<?= $oldtransactionId ?>">
        <span class="error">
            <?php
            if (isset($_SESSION['transactionNameError'])) {
                $transactionNameError = $_SESSION['transactionNameError'];
                echo $transactionNameError;
                unset($_SESSION['transactionNameError']);
            }
            ?>
        </span><br><br>

        <label for="transaction_details">Transaction Details:</label><br>
        <textarea id="transaction_details" name="transaction_details" rows="4" cols="50"><?= $oldtransactionDetails ?></textarea>
        <span class="error">
            <?php
            if (isset($_SESSION['transactionDetailsError'])) {
                $transactionDetailsError = $_SESSION['transactionDetailsError'];
                echo $transactionDetailsError;
                unset($_SESSION['transactionDetailsError']);
            }
            ?>
        </span><br><br>

        <label for="transaction_price">Transaction Amount:</label>
        <input type="number" id="transaction_price" name="transaction_price" step="0.01" min="0" value="<?= $oldtransactionPrice ?>">
        <span class="error">
            <?php
            if (isset($_SESSION['transactionPriceError'])) {
                $transactionPriceError = $_SESSION['transactionPriceError'];
                echo $transactionPriceError;
                unset($_SESSION['transactionPriceError']);
            }
            ?>
        </span><br><br>

        <input type="submit" name="add_transaction" value="Add Transaction">
    </form>
</body>

</html>
