<?php
require_once("../controller/registrationProcess.php");
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (isset($_SESSION['userId'])) {
    header("Location: transaction_list.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['registration'])) {
    $username = $_POST["username"];
    $password = $_POST["password"];

    registrationProcess($username, $password);
}


$oldUserName = '';

if (isset($_SESSION['oldUserName'])) {
    $oldUserName = $_SESSION['oldUserName'];
    unset($_SESSION['oldUserName']);
}
?>
<!DOCTYPE html>
<html>

<head>
    <title>User Registration</title>
    <link rel="stylesheet" type="text/css" href="../public/css/style.css">
</head>

<body>
    <h2>User Registration</h2>
    <span class="error">
        <?php
        if (isset($_SESSION["registration_error"])) {
            echo $_SESSION["registration_error"];
            unset($_SESSION["registration_error"]);
        }
        ?>
    </span>
    <form method="post" action="">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" value="<?= $oldUserName ?>">
        <span class="error">
            <?php
            if (isset($_SESSION['username_error'])) {
                $username_error = $_SESSION['username_error'];
                echo $username_error;
                unset($_SESSION['username_error']);
            }
            ?>
        </span><br><br>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password">
        <span class="error">
            <?php
            if (isset($_SESSION['password_error'])) {
                $password_error = $_SESSION['password_error'];
                echo $password_error;
                unset($_SESSION['password_error']);
            }
            ?>
        </span><br><br>
        <input type="submit" name="registration" value="Registration">
    </form>
    <a href="login.php">Login</a>
</body>

</html>
