<?php
require_once("../controller/logoutProcess.php");
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['logout'])) {
    logout();
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Top Bar</title>
    <style>
        .topbar {
            background-color: #333;
            color: white;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .topbar-links {
            display: flex;
            align-items: center;
        }

        .topbar-links a {
            color: #2196F3;
            margin-right: 10px;
            text-decoration: none;
        }

        .user-info {
            display: flex;
            align-items: center;
        }

        .user-name {
            color: white;
            margin-right: 10px;
        }

        .logout-button {
            background-color: #f44336;
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <div class="topbar">
        <?php if (isset($_SESSION['userId'])) : ?>
            <div class="topbar-links">
                <a href=transaction_list.php>Transaction List</a>
                <a href="transaction_add.php">Add Transaction</a>
            </div>
            <div class="user-info">
                <div class="user-name"><?php echo $_SESSION['userName']; ?></div>
                <form action="" method="post">
                    <input class="logout-button" type="submit" value="Logout" name="logout">
                </form>
            </div>
        <?php endif; ?>
    </div>
</body>

</html>
