<?php
require_once("../controller/transactionProcess.php");
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['userId'])) {
    header("Location: login.php");
    exit();
}

$transactions = transactionList();
?>

<!DOCTYPE html>
<html>

<head>
    <title>Transaction List</title>
    <link rel="stylesheet" type="text/css" href="../public/css/style.css">
</head>

<body>
    <?php include 'include/topbar.php'; ?>
    <h2>Transaction List</h2>
    <div>
        <?php
        if ($transactions) {
        ?>
            <table>
                <tr>
                    <th>Name</th>
                    <th>Details</th>
                    <th>Amount</th>
                    <th>Created Time</th>
                    <th>Status</th>
                </tr>
                <?php
                foreach ($transactions as $transaction) {
                ?>
                    <tr>
                        <td><?php echo $transaction["transaction_name"]; ?></td>
                        <td><?php echo $transaction["transaction_details"]; ?></td>
                        <td><?php echo number_format($transaction["transaction_price"], 2); ?></td>
                        <td><?php echo $transaction["created_time"]; ?></td>
                        <td><?php echo $transaction["status"] ?></td>
                    </tr>
                <?php
                }
                ?>
            </table>
        <?php
        } else {
        ?>
            <span>Currently there is no transaction to show</span>
        <?php
        }
        ?>
    </div>
</body>

</html>
