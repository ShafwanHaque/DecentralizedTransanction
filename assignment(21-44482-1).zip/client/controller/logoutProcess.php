<?php
function logout() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    unset($_SESSION['userId']);
    unset($_SESSION['userName']);
    header("Location: login.php");
    exit();
}
