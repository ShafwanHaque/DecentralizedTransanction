<?php
require_once("../model/transactionModel.php");
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function addtransactionProcess($transaction_name = "", $transaction_details = "", $transaction_price = "")
{
    $transaction_name = trim($transaction_name);
    $transaction_details = trim($transaction_details);
    $transaction_price = trim($transaction_price);
    $errorFlag = false;

    if($transaction_name == "") {
        $_SESSION["transactionNameError"] = "Enter Transaction ID";
        $errorFlag = true;
    }
    if ($transaction_details == "") {
        $_SESSION["transactionDetailsError"] = "Enter Transaction Details";
        $errorFlag = true;
    }
    if ($transaction_price == "") {
        $_SESSION["transactionPriceError"] = "Enter Transaction Amount";
        $errorFlag = true;
    }

    if($errorFlag) {
        $_SESSION["oldtransactionName"] = $transaction_name;
        $_SESSION["oldtransactionDetails"] = $transaction_details;
        $_SESSION["oldtransactionPrice"] = $transaction_price;
        header("Location: transaction_add.php");
        exit();
    }

    if(contract($transaction_name, $transaction_details, $transaction_price)) {
        $_SESSION["transactionInsertSuccess"] = "transaction Added Successfully!";
    } else {
        $_SESSION["transactionInsertError"] = "Something Went Wrong!";
    }
    header("Location: transaction_add.php");
    exit();
}

function transactionList()
{
    $created_by = $_SESSION['userId'];
    return getAlltransactions($created_by);
}
