<?php
require_once("../model/userModel.php");
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function registrationProcess($username = "", $password = "") {
    $username = trim($username);
    $errorFlag = false;
    if($username == "") {
        $_SESSION["username_error"] = "Enter Username";
        $errorFlag = true;
    } else if (isUserNameExist($username)) {
        $_SESSION["username_error"] = "Username already exists! Try a different username";
        $errorFlag = true;
    }

    if ($password == "") {
        $_SESSION["password_error"] = "Enter Password";
        $errorFlag = true;
    } else if(strlen($password) < 6) {
        $_SESSION["password_error"] = "Password cannot be less than 6";
        $errorFlag = true;
    } else if (strlen($password) > 20) {
        $_SESSION["password_error"] = "Password cannot be more than 20";
        $errorFlag = true;
    }

    if($errorFlag) {
        $_SESSION["oldUserName"] = $username;
        header("Location: registration.php");
        exit();
    }

    if(storeUserData($username, $password)) {
        $_SESSION["registration_success"] = "Registration completed!";
        header("location: login.php");
    } else {
        $_SESSION["registration_error"] = "Something went wrong!";
        header("Location: registration.php");
        exit();
    }
}
