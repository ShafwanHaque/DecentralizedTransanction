<?php
require_once("../model/userModel.php");
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function authenticateProcess($username, $password) {
    $row = authenticate($username, $password);
    if ($row) {
        $_SESSION['userId'] = $row['id'];
        $_SESSION['userName'] = $row['user_name'];
        header("location: transaction_list.php");
    } else {
        $_SESSION["login_error"] = "Invalid username or password";
        header("Location: login.php");
        exit();
    }
}
