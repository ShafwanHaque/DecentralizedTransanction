<?php
require_once('../model/transactionModel.php');
function storeApprovedDataProcess()
{
    $data = json_decode($_POST['data'], true);

    storeApprovedData($data);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    storeApprovedDataProcess();
}
