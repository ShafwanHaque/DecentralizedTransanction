<?php
require_once("../controller/loginProcess.php");
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (isset($_SESSION['adminId'])) {
    header("Location: pending_transaction_list.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['login'])) {
    $adminname = $_POST["adminname"];
    $password = $_POST["password"];

    authenticateProcess($adminname, $password);
}
?>
<!DOCTYPE html>
<html>

<head>
    <title>Validator Login</title>
    <link rel="stylesheet" type="text/css" href="../public/css/style.css">
</head>

<body>
    <h2>Validator Login</h2>
    <span class="error">
        <?php
        if (isset($_SESSION["login_error"])) {
            echo $_SESSION["login_error"];
            unset($_SESSION["login_error"]);
        }
        ?>
    </span>
    <form method="post" action="">
        <label for="adminname">Admin Name:</label>
        <input type="text" id="adminname" name="adminname"><br><br>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password"><br><br>
        <input type="submit" name="login" value="Login">
    </form>
</body>

</html>
