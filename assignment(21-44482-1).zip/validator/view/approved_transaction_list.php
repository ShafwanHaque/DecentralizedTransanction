<?php
require_once("../controller/transactionProcess.php");
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['adminId'])) {
    header("Location: login.php");
    exit();
}

$transactions = approvedtransactionList();
?>

<!DOCTYPE html>
<html>

<head>
    <title>Your Approved Transaction List</title>
    <link rel="stylesheet" type="text/css" href="../public/css/style.css">
</head>

<body>
    <?php include 'include/topbar.php'; ?>
    <h2>Your Approved Transaction List</h2>

    <?php
    if ($transactions) {
    ?>
        <table>
            <tr>
                <th>Name</th>
                <th>Details</th>
                <th>Price</th>
                <th>Created By</th>
                <th>Created Time</th>
                <th>Approval Time</th>
            </tr>
            <?php
            foreach ($transactions as $transaction) {
            ?>
                <tr>
                    <td><?php echo $transaction["transaction_name"]; ?></td>
                    <td><?php echo $transaction["transaction_details"]; ?></td>
                    <td><?php echo number_format($transaction["transaction_price"], 2); ?></td>
                    <td><?php echo $transaction["created_by_name"]; ?></td>
                    <td><?php echo $transaction["created_time"]; ?></td>
                    <td><?php echo $transaction["approval_time"]; ?></td>
                </tr>
            <?php
            }
            ?>
        </table>
    <?php
    } else {
    ?>
        <span>Currently there is no approved transaction to show</span>
    <?php
    }
    ?>
</body>

</html>
