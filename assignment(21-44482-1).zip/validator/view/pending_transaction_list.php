<?php
require_once("../controller/transactionProcess.php");
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['adminId'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['approve'])) {
    $id = $_POST["id"];
    approvetransactionProcess($id);
}

$transactions = pendingtransactionList();
?>

<!DOCTYPE html>
<html>

<head>
    <title>Pending transaction List</title>
    <link rel="stylesheet" type="text/css" href="../public/css/style.css">
</head>

<body>
    <?php include 'include/topbar.php'; ?>
    <h2>Pending transaction List</h2>
    <?php
    if (isset($_SESSION['transactionApprovalSuccess'])) {
        $transactionApprovalSuccess = $_SESSION['transactionApprovalSuccess'];
        unset($_SESSION['transactionApprovalSuccess']);
    ?>
        <span class="success"><?= $transactionApprovalSuccess; ?></span><br>
    <?php
    }
    ?>
    <?php
    if (isset($_SESSION['transactionApprovalError'])) {
        $transactionApprovalError = $_SESSION['transactionApprovalError'];
        unset($_SESSION['transactionApprovalError']);
    ?>
        <span class="error"><?= $transactionApprovalError; ?></span><br>
    <?php
    }
    ?>

    <?php
    if ($transactions) {
    ?>
        <table>
            <tr>
                <th>Name</th>
                <th>Details</th>
                <th>Price</th>
                <th>Created By</th>
                <th>Created Time</th>
                <th>Approval Percentage</th>
                <th></th>
            </tr>
            <?php
            foreach ($transactions as $transaction) {
            ?>
                <form method="post" action="">
                    <input type="hidden" name="id" value="<?= $transaction["id"]; ?>" />
                    <tr>
                        <td><?php echo $transaction["transaction_name"]; ?></td>
                        <td><?php echo $transaction["transaction_details"]; ?></td>
                        <td><?php echo number_format($transaction["transaction_price"], 2); ?></td>
                        <td><?php echo $transaction["created_by_name"]; ?></td>
                        <td><?php echo $transaction["created_time"]; ?></td>
                        <td><?php echo $transaction["approval_percentage"]; ?></td>
                        <td><input type="submit" name="approve" value="Approve"></td>
                    </tr>
                </form>
            <?php
            }
            ?>
        </table>
    <?php
    } else {
    ?>
        <span>Currently there is no pending transaction to show</span>
    <?php
    }
    ?>
</body>

</html>
