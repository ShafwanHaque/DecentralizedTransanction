<?php
require_once("../controller/logoutProcess.php");
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['logout'])) {
    logout();
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Top Bar</title>
    <style>
        /* Add your CSS styles for the top bar here */
        .topbar {
            background-color: #333;
            color: white;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .topbar-links {
            display: flex;
            align-items: center;
        }

        .topbar-links a {
            color: #2196F3;
            margin-right: 10px;
            text-decoration: none;
        }

        .admin-info {
            display: flex;
            align-items: center;
        }

        .admin-name {
            color: white;
            margin-right: 10px;
        }

        .logout-button {
            background-color: #f44336;
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <div class="topbar">
        <?php if (isset($_SESSION['adminId'])) : ?>
            <div class="topbar-links">
                <a href="pending_transaction_list.php">Pending transactions</a>
                <a href="approved_transaction_list.php">Approved transactions</a>
            </div>
            <div class="admin-info">
                <div class="admin-name"><?php echo $_SESSION['adminName']; ?></div>
                <form action="" method="post">
                    <button class="logout-button" name="logout" type="submit">Logout</button>
                </form>
            </div>
        <?php endif; ?>
    </div>
</body>

</html>
