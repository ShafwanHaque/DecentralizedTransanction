<?php
function logout() {
    if (session_status() === PHP_SESSION_NONE) {
            session_start();
    }
    unset($_SESSION['adminId']);
    unset($_SESSION['adminName']);
    header("Location: login.php");
    exit();
}
