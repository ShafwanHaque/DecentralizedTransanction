<?php
require_once('../model/transactionModel.php');
function storePendingDataProcess() {
    $data = json_decode($_POST['data'], true);

    storePendingData($data);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    storePendingDataProcess();
}
