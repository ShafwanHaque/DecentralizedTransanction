<?php
require_once("../model/adminModel.php");

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function countAdmin()
{
    return count(getAllAdmin());
}
