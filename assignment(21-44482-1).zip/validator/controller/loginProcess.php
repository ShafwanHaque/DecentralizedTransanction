<?php
require_once("../model/adminModel.php");
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function authenticateProcess($adminname, $password) {
    $admins = getAllAdmin();

    if($admins) {
        foreach ($admins as $admin) {
            if ($admin['admin_name'] === $adminname && $admin['password'] === $password) {
                $_SESSION['adminId'] = $admin['id'];
                $_SESSION['adminName'] = $admin['admin_name'];
                header("location: pending_transaction_list.php");
                exit();
            }
        }
    }

    $_SESSION["login_error"] = "Invalid adminname or password";
    header("Location: login.php");
    exit();
}
