<?php
require_once("../model/transactionModel.php");
require_once("../db/db_connection.php");
require_once("adminProcess.php");
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function pendingtransactionList()
{
    $adminName = $_SESSION['adminName'];
    $pendingtransactions = getAllPendingtransactions($adminName) ?? [];
    $pendingtransactions = getAllPendingtransactions($adminName) ?? [];
    
    //var_dump($pendingtransactions);
    $countAdmin = countAdmin();
    foreach ($pendingtransactions as $key => $value) {
        $percentage = ($value['vote'] / $countAdmin) * 100;
        $formattedPercentage = number_format($percentage, 2);
        $pendingtransactions[$key]['approval_percentage'] = $formattedPercentage;
    }
    return $pendingtransactions;
}

function getUserDeposit($userId)
{
    global $conn; // Assuming you have a database connection established here
    $sql = "SELECT deposite FROM users WHERE id = '$userId'";
    $result = mysqli_query($conn, $sql);
    
    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        return $row['deposite'];
    }
    
    return 0; // Return 0 if user not found or deposit not available
}
function updateDeposit($userId, $amount)
{
    global $conn; // Assuming you have a database connection established here

    // Update sender's deposit
    $senderId = $userId; // Assuming the sender's ID is passed as $userId
    $senderSql = "UPDATE users SET deposite = deposite - '$amount' WHERE id = '$senderId'";
    
    // Update receiver's deposit
    $receiverId = getUserIdFromName($userId); // Assuming a function that gets receiver's ID based on Name
    $receiverSql = "UPDATE users SET deposite = deposite + '$amount' WHERE id = '$receiverId'";
    
    // Execute both queries
    if ($conn->query($senderSql) && $conn->query($receiverSql)) {
        return true;
    } else {
        return false;
    }
}

function getUserIdFromName($userName)
{
    global $conn; // Assuming you have a database connection established here

    $sql = "SELECT id FROM users WHERE Name = '$userName'";
    $result = mysqli_query($conn, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        return $row['id'];
    }

    return null; // Return null if user not found
}


function approvedtransactionList()
{
    $adminName = $_SESSION['adminName'];
    $approvedtransactions = getAllApprovedtransactions($adminName);
    return $approvedtransactions;
}

function approvetransactionProcess($id)
{
    $adminName = $_SESSION['adminName'];
    $countAdmin = countAdmin();
    if(approvetransaction($id, $adminName, $countAdmin)) {
        $_SESSION["transactionApprovalSuccess"] = "transaction Approval Successful!";
    } else {
        $_SESSION["transactionApprovalError"] = "Something Went Wrong!";
    }
    header("location: pending_transaction_list.php");
    exit();
}
