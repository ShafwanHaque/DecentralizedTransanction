<?php
$jsonFilePath = '../json/pending_transaction.json';

$jsonData = file_get_contents($jsonFilePath);
$entries = json_decode($jsonData, true);

$currentTime = time();

foreach ($entries as $key => $entry) {
    $expiryTime = strtotime($entry['expiry_time']);
    if ($currentTime >= $expiryTime) {
        unset($entries[$key]);
    }
}

$entries = array_values($entries);

file_put_contents($jsonFilePath, json_encode($entries, JSON_PRETTY_PRINT));
?>
