<?php
function getAllAdmin() {
    $jsonData = file_get_contents('../json/admins.json');
    $admins = json_decode($jsonData, true);

    return $admins;
}
