<?php
function storePendingData($data) {
    $jsonFilePath = '../json/pending_transaction.json';

    $jsonData = file_get_contents($jsonFilePath);
    $entries = json_decode($jsonData, true);

    $entries[] = $data;

    file_put_contents($jsonFilePath, json_encode($entries, JSON_PRETTY_PRINT));
}

function storeApproveData($adminName, $data)
{
    $allreadyApprovedtransactions = getAllApprovedtransactions($adminName) ?? [];
    $exists = false;
    foreach ($allreadyApprovedtransactions as $key => $value) {
        if($data['id'] == $value['id']) {
            $exists = true;
            break;
        }
    }
    if(!$exists) {
        unset($data['vote']);
        $jsonFileName = '../json/' . $adminName . '.json';

        $jsonData = file_get_contents($jsonFileName);
        $entries = json_decode($jsonData, true);

        $entries[] = $data;

        if (file_put_contents($jsonFileName, json_encode($entries, JSON_PRETTY_PRINT))) {
            return true;
        } else {
            return false;
        }
    }
}

function getAllPendingtransactions($adminName)
{
    $jsonData = file_get_contents('../json/pending_transaction.json');
    $pendingtransactions = json_decode($jsonData, true) ?? [];


    $adminApprovedtransactions = [];
    $jsonFileName = '../json/' . $adminName . '.json';
    if (file_exists($jsonFileName)) {
        $adminApprovedJsonData = file_get_contents($jsonFileName);
        $adminApprovedtransactions = json_decode($adminApprovedJsonData, true) ?? [];

        $admintransactionsById = [];
        foreach ($adminApprovedtransactions as $admintransaction) {
            $admintransactionsById[$admintransaction['id']] = true;
        }

        $filteredPendingtransactions = [];
        foreach ($pendingtransactions as $pendingtransaction) {
            if (!isset($admintransactionsById[$pendingtransaction['id']])) {
                $filteredPendingtransactions[] = $pendingtransaction;
            }
        }

        return $filteredPendingtransactions;
    } else {
        return $pendingtransactions;
    }
}

function getAllApprovedtransactions($adminName)
{
    $adminApprovedtransactions = [];
    $jsonFileName = '../json/' . $adminName . '.json';
    if (file_exists($jsonFileName)) {
        $adminApprovedJsonData = file_get_contents($jsonFileName);
        $adminApprovedtransactions = json_decode($adminApprovedJsonData, true);
    }
    return $adminApprovedtransactions;
}

function approvetransaction($id, $adminName, $countAdmin)
{
    try {
        $jsonData = file_get_contents('../json/pending_transaction.json');
        $data = json_decode($jsonData, true) ?? [];
        $removeFlag = false;
        $hasFlag = false;

        foreach ($data as $key => $record) {
            if ($record['id'] == $id) {
                $hasFlag = true;
                date_default_timezone_set('Asia/Dhaka');
                $approval_time = date("Y-m-d H:i:s");
                $record['approval_time'] = $approval_time;
                if(storeApproveData($adminName, $record)) {
                    $data[$key]['vote']++;
                    if((number_format((($data[$key]['vote'] / $countAdmin) * 100), 2)) >= 51) {
                        // sending transactions approved by 51% > admin to client
                        $url = 'http://localhost/client/controller/transactionsApi.php';

                        $newEntry = array(
                            "id" => $id
                        );

                        $postData = http_build_query(array('data' => json_encode($newEntry)));

                        $ch = curl_init();
                        curl_setopt($ch, CURLOPT_URL, $url);
                        curl_setopt($ch, CURLOPT_POST, 1);
                        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

                        $response = curl_exec($ch);
                        curl_close($ch);

                        $adminData = file_get_contents('../json/admins.json');
                        $admins = json_decode($adminData, true);

                        foreach ($admins as $key => $value) {
                            if($value['admin_name'] != $adminName) {
                                storeApproveData($value['admin_name'], $record);
                            }
                        }

                        $removeFlag = true;
                    }
                } else {
                    return false;
                }
                break;
            }
        }

        // no matching transaction to approve
        if(!$hasFlag) {
            return false;
        }
        $updatedJsonData = json_encode($data, JSON_PRETTY_PRINT);
        file_put_contents('../json/pending_transaction.json', $updatedJsonData);
        if($removeFlag) {
            removePendingtransaction($id);
        }

        return true;
    } catch (Exception $ex) {
        return false;
    }
}

function removePendingtransaction($id)
{
    $jsonFilePath = '../json/pending_transaction.json';
    $data = file_get_contents($jsonFilePath);

    $json_arr = json_decode($data, true) ?? [];

    $arr_index = array();
    foreach ($json_arr as $key => $value) {
        if ($value['id'] == $id) {
            $arr_index[] = $key;
        }
    }

    foreach ($arr_index as $i) {
        unset($json_arr[$i]);
    }

    $json_arr = array_values($json_arr);

    file_put_contents($jsonFilePath, json_encode($json_arr, JSON_PRETTY_PRINT));
}
